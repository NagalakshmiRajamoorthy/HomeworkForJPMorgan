
public class Stock {
	ReferenceStock refStock;
	int price;

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	
	
	public ReferenceStock getRefStock() {
		return refStock;
	}

	public void setRefStock(ReferenceStock refStock) {
		this.refStock = refStock;
	}

	public float getDividendYield(int Price){
		if(refStock.type == "Common"){
			return refStock.lastDividend/Price;
		}else
			return (refStock.fixedDividend*refStock.parValue)/Price;
	}
	
	public float getPERatio(int Price){
		if(refStock.type == "Common"){
			return (Price*Price)/refStock.lastDividend;
		}else
			return (Price*Price)/(refStock.fixedDividend*refStock.parValue);
	}
}
