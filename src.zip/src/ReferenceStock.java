
public class ReferenceStock {
	String type;
	int lastDividend;
	float fixedDividend;
	int parValue;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getLastDividend() {
		return lastDividend;
	}

	public void setLastDividend(int lastDividend) {
		this.lastDividend = lastDividend;
	}

	public float getFixedDividend() {
		return fixedDividend;
	}

	public void setFixedDividend(float fixedDividend) {
		this.fixedDividend = fixedDividend;
	}

	public int getParValue() {
		return parValue;
	}

	public void setParValue(int parValue) {
		this.parValue = parValue;
	}

}
