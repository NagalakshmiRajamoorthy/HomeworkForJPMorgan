import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class SimpleStockMarket {
	
	static HashMap referenceStocks = new HashMap();
	static List<Stock> listStock = new ArrayList<Stock>();
	
	static List<Trade> listTrade = new ArrayList<Trade>();
	
	public static void main(String[] args){
			
		//Populate reference Stock table
		ReferenceStock rfStock = new ReferenceStock();
		rfStock.setType("Common");
		rfStock.setLastDividend(0);
		rfStock.setFixedDividend(0);
		rfStock.setParValue(100);
		referenceStocks.put("TEA", rfStock);
		rfStock.setType("Common");
		rfStock.setLastDividend(8);
		rfStock.setFixedDividend(0);
		rfStock.setParValue(100);
		referenceStocks.put("POP", rfStock);
		rfStock.setType("Common");
		rfStock.setLastDividend(23);
		rfStock.setFixedDividend(0);
		rfStock.setParValue(60);
		referenceStocks.put("ALE", rfStock);
		rfStock.setType("Preferred");
		rfStock.setLastDividend(8);
		rfStock.setFixedDividend(0.02f);
		rfStock.setParValue(100);
		referenceStocks.put("GIN", rfStock);
		rfStock.setType("Common");
		rfStock.setLastDividend(13);
		rfStock.setFixedDividend(0);
		rfStock.setParValue(250);
		referenceStocks.put("JOE", rfStock);
	
		//Get input
		String stockSymbol; 
		int price;
		float dividendYield;
		float peRatio;
		Date time;
		Trade trade = new Trade();
	    Scanner in = new Scanner(System.in);
	    System.out.println("Please enter Stock Symbol");
	    stockSymbol = in.nextLine();
	    System.out.println("Please enter Stock Price");
	    price = in.nextInt();
	    ReferenceStock rs = (ReferenceStock)referenceStocks.get(stockSymbol);
	    Stock stock = new Stock();
		stock.setRefStock(rs);
		listStock.add(stock);
		dividendYield = stock.getDividendYield(price);
		peRatio = stock.getPERatio(price);
		System.out.println("Dividend yield: " + dividendYield);
		System.out.println("PE Ratio: " + peRatio);
		
		System.out.println("Please enter timestamp");
	    time = new Date();
	    time.parse(in.nextLine());
	    trade.setTimestamp(time);
	    
	    System.out.println("Please enter trade Price");
	    trade.setTradePrice(in.nextInt());
		
	    System.out.println("Please enter number Of Shares");
	    trade.setQuantityOfShares(in.nextInt());
	    
	    System.out.println("Please enter buyOrSellIndicator");
	    trade.setBuyOrSellIndicator(in.nextInt());
	    
	    Date currentTime = new Date();
	    long period = currentTime.getMinutes();
	    Date allowedTime = new Date(period - 15);
	    
	    if(!(time.compareTo(allowedTime) < 0)){
	    	listTrade.add(trade);
	    }
	    
	    float volumeWeightedStockPrice = calculateVolumeWeightedStockPrice();
	    System.out.println("volumeWeightedStockPrice: " + volumeWeightedStockPrice);
	    System.out.println("geometricMean: " + getGeometricMean());

	}

	static float calculateVolumeWeightedStockPrice()
	{
		int tradePriceQuantitySum = 0;
		int quantitySum = 0;
		for(Trade trade : listTrade){
			tradePriceQuantitySum = tradePriceQuantitySum + trade.getTradePrice() * trade.getQuantityOfShares();
			quantitySum = quantitySum + trade.getQuantityOfShares();
		}
		return tradePriceQuantitySum/quantitySum;
	}
	
	static float getGeometricMean(){
		int totalPrice = 1;
		for (Stock stock : listStock){
			totalPrice = totalPrice * stock.getPrice();
		}
		return (float)Math.pow(totalPrice, 1.0/listStock.size());
	}
	
	
}
