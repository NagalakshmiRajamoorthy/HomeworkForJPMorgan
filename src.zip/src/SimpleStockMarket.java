import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class SimpleStockMarket {
	
	static HashMap referenceStocks = new HashMap();
	static List<Stock> listStock = new ArrayList<Stock>();
	
	static List<Trade> listTrade = new ArrayList<Trade>();
	
	public static void main(String[] args){
			
		//Populate reference Stock table
		ReferenceStock rfStock = new ReferenceStock();
		rfStock.setType("Common");
		rfStock.setLastDividend(0);
		rfStock.setFixedDividend(0);
		rfStock.setParValue(100);
		referenceStocks.put("TEA", rfStock);
		rfStock.setType("Common");
		rfStock.setLastDividend(8);
		rfStock.setFixedDividend(0);
		rfStock.setParValue(100);
		referenceStocks.put("POP", rfStock);
		rfStock.setType("Common");
		rfStock.setLastDividend(23);
		rfStock.setFixedDividend(0);
		rfStock.setParValue(60);
		referenceStocks.put("ALE", rfStock);
		rfStock.setType("Preferred");
		rfStock.setLastDividend(8);
		rfStock.setFixedDividend(0.02f);
		rfStock.setParValue(100);
		referenceStocks.put("GIN", rfStock);
		rfStock.setType("Common");
		rfStock.setLastDividend(13);
		rfStock.setFixedDividend(0);
		rfStock.setParValue(250);
		referenceStocks.put("JOE", rfStock);
	
		//Get input
		Scanner in = new Scanner(System.in);
		String answer = "y";
		while (answer.equalsIgnoreCase("y")) {
			String stockSymbol; 
			int price;
			float dividendYield;
			float peRatio;
			Date time = new Date();
			Trade trade = new Trade();
		    
		    System.out.println("Please enter Stock Symbol");
		    stockSymbol = in.next();
		    System.out.println("Please enter Stock Price");
		    price = in.nextInt();
		    ReferenceStock rs = (ReferenceStock)referenceStocks.get(stockSymbol);
		    Stock stock = new Stock();
		    stock.setPrice(price);
			stock.setRefStock(rs);
			listStock.add(stock);
			dividendYield = stock.getDividendYield(price);
			peRatio = stock.getPERatio(price);
			System.out.println("Dividend yield: " + dividendYield);
			System.out.println("PE Ratio: " + peRatio);
			
			
			String inputTime;
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

			System.out.println("Please enter timestamp in yyyy-MM-ddTHH:mm:ss");
		    
		    inputTime = in.next(); 
		    try{
		    time = formatter.parse(inputTime);
		    }catch(ParseException e){
		    	e.printStackTrace();
		    }
		    trade.setTimestamp(time);
		    
		    System.out.println("Please enter trade Price");
		    trade.setTradePrice(in.nextInt());
			
		    System.out.println("Please enter number Of Shares");
		    trade.setQuantityOfShares(in.nextInt());
		    
		    System.out.println("Please enter buyOrSellIndicator");
		    trade.setBuyOrSellIndicator(in.nextInt());
		    
		    Date currentTime = new Date();
		    Calendar calendar = Calendar.getInstance();
		    calendar.setTime(currentTime);
		    calendar.add(calendar.MINUTE, -15);
		    
		    Date allowedTime = calendar.getTime();
		    
		    if(!(time.compareTo(allowedTime) < 0)){
		    	System.out.println("Timestamp is within 15 minutes");
		    	listTrade.add(trade);
		    }
		    
		    System.out.println("Continue?[Y/N]");
		    answer = in.next();
		    if (answer.equalsIgnoreCase("n"))
		    {
		    break;
		    }

		}
			    
	    float volumeWeightedStockPrice = calculateVolumeWeightedStockPrice();
	    System.out.println("volumeWeightedStockPrice: " + volumeWeightedStockPrice);
	    System.out.println("geometricMean: " + getGeometricMean());

	}

	static float calculateVolumeWeightedStockPrice()
	{
		int tradePriceQuantitySum = 0;
		int quantitySum = 0;
		for(Trade trade : listTrade){
			tradePriceQuantitySum = tradePriceQuantitySum + trade.getTradePrice() * trade.getQuantityOfShares();
			quantitySum = quantitySum + trade.getQuantityOfShares();
		}
		return tradePriceQuantitySum/quantitySum;
	}
	
	static float getGeometricMean(){
		int totalPrice = 1;
		for (Stock stock : listStock){
			System.out.println("Stored price: "+stock.getPrice());
			totalPrice = totalPrice * stock.getPrice();
		}
		return (float)Math.pow(totalPrice, 1.0/listStock.size());
	}
	
	
}
