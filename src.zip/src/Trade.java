import java.util.Date;

public class Trade {
Date timestamp;
int quantityOfShares;
int buyOrSellIndicator;
int tradePrice;
public Date getTimestamp() {
	return timestamp;
}
public void setTimestamp(Date timestamp) {
	this.timestamp = timestamp;
}
public int getQuantityOfShares() {
	return quantityOfShares;
}
public void setQuantityOfShares(int quantityOfShares) {
	this.quantityOfShares = quantityOfShares;
}
public int getBuyOrSellIndicator() {
	return buyOrSellIndicator;
}
public void setBuyOrSellIndicator(int buyOrSellIndicator) {
	this.buyOrSellIndicator = buyOrSellIndicator;
}
public int getTradePrice() {
	return tradePrice;
}
public void setTradePrice(int tradePrice) {
	this.tradePrice = tradePrice;
}
}
